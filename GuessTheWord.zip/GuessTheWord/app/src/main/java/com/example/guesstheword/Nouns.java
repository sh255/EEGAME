package com.example.guesstheword;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class Nouns extends AppCompatActivity {
    public static final String words[]={"is","working","helped","was","should","Saahil","Lahore","RYK","Apple","Afaaq"};
    public static int answer;
    public static int lives ;
    public static int scores ;
    public static TextView wordTextView;
    public static TextView livesTextView;
    public static TextView scoresTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nouns);
        wordTextView = findViewById(R.id.isWord);
        livesTextView = findViewById(R.id.lives);
        scoresTextView = findViewById(R.id.scores);
        lives = 3;
        scores = 0;
        answer = new Random().nextInt(words.length);
        String randomStr = words[answer];
        wordTextView.setText(randomStr);
    }
    public void yes(View view) {
        if(answer >= 5 && answer <9){
            Toast.makeText(getApplicationContext() , "Answer is correct "+words[answer]+" is a helping verb",Toast.LENGTH_SHORT).show();
            answer = new Random().nextInt(words.length);
            String randomStr = words[answer];
            wordTextView.setText(randomStr);
            scores +=1;
            scoresTextView.setText(String.valueOf(scores));
            if(scores >= 3){
                createSuccessDialog();
            }
        }
        else{
            Toast.makeText(getApplicationContext() , "Answer is incorrect "+words[answer]+" is a not helping verb",Toast.LENGTH_SHORT).show();
            answer = new Random().nextInt(words.length);
            String randomStr = words[answer];
            wordTextView.setText(randomStr);
            lives -=1;
            livesTextView.setText(String.valueOf(lives));
            if(lives < 1){
                createGameOverDialog();
            }
        }
    }

    public void no(View view) {
        if(answer >= 0 && answer <5){
            Toast.makeText(getApplicationContext() , "Answer is correct "+words[answer]+" is a not helping verb",Toast.LENGTH_SHORT).show();
            answer = new Random().nextInt(words.length);
            String randomStr = words[answer];
            wordTextView.setText(randomStr);
            scores +=1;
            scoresTextView.setText(String.valueOf(scores));
            if(scores >= 3){
                createSuccessDialog();
            }
        }
        else{
            Toast.makeText(getApplicationContext() , "Answer is incorrect "+words[answer]+" is a helping verb",Toast.LENGTH_SHORT).show();
            answer = new Random().nextInt(words.length);
            String randomStr = words[answer];
            wordTextView.setText(randomStr);
            lives -=1;
            livesTextView.setText(String.valueOf(lives));
            if(lives < 1){
                createGameOverDialog();
            }
        }
    }

    public void createSuccessDialog(){
        AlertDialog.Builder alertDialog2 = new AlertDialog.Builder(
                Nouns.this);

// Setting Dialog Title
        alertDialog2.setTitle("WoW...!");

// Setting Dialog Message
        alertDialog2.setMessage("Congratulation You completed the Game");

// Setting Icon to Dialog
        //alertDialog2.setIcon(R.drawable.delete);

// Setting Positive "Yes" Btn
        alertDialog2.setPositiveButton("Home",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Write your code here to execute after dialog
//                        Toast.makeText(getApplicationContext(),
//                                "You clicked on YES", Toast.LENGTH_SHORT)
//                                .show();
                        Intent intent = new Intent(getApplicationContext() , MainActivity.class);
                        startActivity(intent);
                    }
                });
// Setting Negative "NO" Btn
//        alertDialog2.setNegativeButton("NO",
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // Write your code here to execute after dialog
////                        Toast.makeText(getApplicationContext(),
////                                "You clicked on NO", Toast.LENGTH_SHORT)
////                                .show();
//                        dialog.cancel();
//                        Intent intent = new Intent(getApplicationContext() , MainActivity.class);
//                        startActivity(intent);
//                    }
//                });

// Showing Alert Dialog
        alertDialog2.show();
    }

    public void createGameOverDialog(){
        AlertDialog.Builder alertDialog1 = new AlertDialog.Builder(
                Nouns.this);

        // Setting Dialog Title
        alertDialog1.setTitle("Oops...!");

        // Setting Dialog Message
        alertDialog1.setMessage("You Failed and now you are out of Lives Try Again");

        // Setting Icon to Dialog
        //alertDialog1.setIcon(R.drawable.tick);

        // Setting OK Button
        alertDialog1.setPositiveButton("Back", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                // Write your code here to execute after dialog
                // closed
//                Toast.makeText(getApplicationContext(),
//                        "You clicked on OK", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext() , MainActivity.class);
                startActivity(intent);
            }
        });

        // Showing Alert Message
        alertDialog1.show();
    }
}